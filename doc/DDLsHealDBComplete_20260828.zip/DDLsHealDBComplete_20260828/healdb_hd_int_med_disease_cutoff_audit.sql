-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: healdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hd_int_med_disease_cutoff_audit`
--

DROP TABLE IF EXISTS `hd_int_med_disease_cutoff_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_int_med_disease_cutoff_audit` (
  `id_medication` int NOT NULL,
  `nr_entity_id` int NOT NULL,
  `ds_entity_text` varchar(2000) NOT NULL,
  `tp_entity` varchar(255) DEFAULT NULL,
  `ds_category` varchar(255) DEFAULT NULL,
  `vl_entity_score` double DEFAULT NULL,
  `nr_begin_offset` int DEFAULT NULL,
  `nr_end_offset` int DEFAULT NULL,
  `ds_attributes` json DEFAULT NULL,
  `cd_icd10cm_full` varchar(15) NOT NULL,
  `cd_icd10cm_nodot` varchar(15) DEFAULT NULL,
  `ds_icd10cm` varchar(1000) DEFAULT NULL,
  `vl_icd10cm_score` double DEFAULT NULL,
  `tp_icd10cm_score_level` enum('LOW','MEDIUM','HIGH') DEFAULT NULL,
  `fl_negation` tinyint(1) NOT NULL DEFAULT '0',
  `nm_trait_main` varchar(100) DEFAULT NULL,
  `vl_trait_main_score` double DEFAULT NULL,
  `cd_icd10_nodot` varchar(15) DEFAULT NULL,
  `tp_icd10_map` enum('SUBCAT_EXACT','CAT3_FALLBACK','NO_MAP') DEFAULT NULL,
  `id_icd_group` int DEFAULT NULL,
  `id_icd_cat` int DEFAULT NULL,
  `id_icd_subcat` int DEFAULT NULL,
  `fl_pass_dx_name` tinyint(1) DEFAULT NULL,
  `fl_pass_negation` tinyint(1) DEFAULT NULL,
  `fl_pass_entity_score` tinyint(1) DEFAULT NULL,
  `fl_pass_all_pre` tinyint(1) DEFAULT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_medication`,`nr_entity_id`),
  KEY `idx_med_icd10cm` (`id_medication`,`cd_icd10cm_full`),
  KEY `idx_med_icd10` (`id_medication`,`cd_icd10_nodot`),
  KEY `idx_icd_ids` (`id_icd_group`,`id_icd_cat`,`id_icd_subcat`),
  KEY `FK_AUDIT_ICD_CAT` (`id_icd_cat`),
  KEY `FK_AUDIT_ICD_SUBCAT` (`id_icd_subcat`),
  CONSTRAINT `FK_AUDIT_ICD_CAT` FOREIGN KEY (`id_icd_cat`) REFERENCES `hd_icd_category` (`id_cat`),
  CONSTRAINT `FK_AUDIT_ICD_GROUP` FOREIGN KEY (`id_icd_group`) REFERENCES `hd_icd_group` (`id_group`),
  CONSTRAINT `FK_AUDIT_ICD_SUBCAT` FOREIGN KEY (`id_icd_subcat`) REFERENCES `hd_icd_subcategory` (`id_subcat`),
  CONSTRAINT `FK_MEDICATION_ACM_AUDIT` FOREIGN KEY (`id_medication`) REFERENCES `hd_medication` (`id_medication`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-28  0:15:35
