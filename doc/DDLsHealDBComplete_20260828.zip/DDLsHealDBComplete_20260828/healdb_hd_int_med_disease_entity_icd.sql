-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: healdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hd_int_med_disease_entity_icd`
--

DROP TABLE IF EXISTS `hd_int_med_disease_entity_icd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_int_med_disease_entity_icd` (
  `id_medication` int NOT NULL,
  `nr_entity_id` int NOT NULL,
  `ds_entity_text` varchar(2000) NOT NULL,
  `tp_entity` varchar(255) DEFAULT NULL,
  `ds_category` varchar(255) DEFAULT NULL,
  `vl_entity_score` double DEFAULT NULL,
  `nr_begin_offset` int DEFAULT NULL,
  `nr_end_offset` int DEFAULT NULL,
  `ds_attributes` json DEFAULT NULL,
  `cd_icd_full` varchar(15) NOT NULL,
  `ds_icd` varchar(1000) DEFAULT NULL,
  `vl_icd_score` double DEFAULT NULL,
  PRIMARY KEY (`id_medication`,`nr_entity_id`,`cd_icd_full`),
  KEY `idx_med_icd` (`id_medication`,`cd_icd_full`),
  KEY `idx_med_entity` (`id_medication`,`nr_entity_id`),
  CONSTRAINT `FK_MEDICATION_ACM_EICD` FOREIGN KEY (`id_medication`) REFERENCES `hd_medication` (`id_medication`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-28  0:15:32
