-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: healdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hd_medication`
--

DROP TABLE IF EXISTS `hd_medication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_medication` (
  `id_medication` int NOT NULL AUTO_INCREMENT,
  `nr_register` int NOT NULL,
  `nm_medication` varchar(100) NOT NULL,
  `id_regulatory_category` int NOT NULL,
  `dt_expiration` date DEFAULT NULL,
  `id_therapeutic_class` int DEFAULT NULL,
  `id_company` int NOT NULL,
  `fl_status` varchar(30) NOT NULL,
  `ds_active_ingredients` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id_medication`),
  UNIQUE KEY `nr_register` (`nr_register`),
  KEY `id_regulatory_category` (`id_regulatory_category`),
  KEY `id_therapeutic_class` (`id_therapeutic_class`),
  KEY `id_company` (`id_company`),
  CONSTRAINT `hd_medication_ibfk_1` FOREIGN KEY (`id_regulatory_category`) REFERENCES `hd_regulatory_category` (`id_regulatory_category`),
  CONSTRAINT `hd_medication_ibfk_2` FOREIGN KEY (`id_therapeutic_class`) REFERENCES `hd_therapeutic_class` (`id_therapeutic_class`),
  CONSTRAINT `hd_medication_ibfk_3` FOREIGN KEY (`id_company`) REFERENCES `hd_company` (`id_company`)
) ENGINE=InnoDB AUTO_INCREMENT=10549 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-06  1:00:17
