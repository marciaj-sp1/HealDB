-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: healdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hd_icd_subcategory`
--

DROP TABLE IF EXISTS `hd_icd_subcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_icd_subcategory` (
  `id_subcat` int NOT NULL AUTO_INCREMENT,
  `id_cat` int NOT NULL,
  `cd_subcat` varchar(4) NOT NULL,
  `ds_subcat` varchar(300) NOT NULL,
  `ds_subcat_abbrev` varchar(200) NOT NULL,
  `tp_classif` varchar(100) DEFAULT NULL,
  `fl_restrgender` varchar(45) DEFAULT NULL,
  `cd_refer` varchar(45) DEFAULT NULL,
  `cd_excluded` varchar(45) DEFAULT NULL,
  `ds_subcat_eng` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id_subcat`,`id_cat`),
  UNIQUE KEY `subcat_UNIQUE` (`cd_subcat`),
  KEY `FK_categoria_idx` (`id_cat`),
  CONSTRAINT `FK_categoria` FOREIGN KEY (`id_cat`) REFERENCES `hd_icd_category` (`id_cat`)
) ENGINE=InnoDB AUTO_INCREMENT=12452 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-06  1:00:18
