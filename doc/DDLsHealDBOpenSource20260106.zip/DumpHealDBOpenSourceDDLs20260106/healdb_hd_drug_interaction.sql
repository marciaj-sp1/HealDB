-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: healdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hd_drug_interaction`
--

DROP TABLE IF EXISTS `hd_drug_interaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_drug_interaction` (
  `id_drug_interaction` int NOT NULL AUTO_INCREMENT,
  `id_interaction` int NOT NULL,
  `id_active_ingredient` int NOT NULL,
  `id_active_ingredient_2` int NOT NULL,
  PRIMARY KEY (`id_drug_interaction`),
  KEY `FK_ACTIVE_INGREDIENT_INT1_idx` (`id_active_ingredient`),
  KEY `FK_ACT_INGRED_INT_idx` (`id_active_ingredient_2`),
  KEY `FK_INTERACTION_DRUG` (`id_interaction`),
  CONSTRAINT `FK_ACT_INGRED` FOREIGN KEY (`id_active_ingredient`) REFERENCES `hd_active_ingredient` (`id_active_ingredient`),
  CONSTRAINT `FK_ACT_INGRED_INT` FOREIGN KEY (`id_active_ingredient_2`) REFERENCES `hd_active_ingredient` (`id_active_ingredient`),
  CONSTRAINT `FK_INTERACTION_DRUG` FOREIGN KEY (`id_interaction`) REFERENCES `db_drug_interaction` (`id_interaction`)
) ENGINE=InnoDB AUTO_INCREMENT=775213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-06  1:08:04
